package com.cg.obs.controller;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.ServiceRequest;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.UserTable;
import com.cg.obs.exception.BankingException;
import com.cg.obs.exception.IBankingException;
import com.cg.obs.service.IUserService;

@Controller
public class UserController {
	Long accountId;
	Account account;
	Customer customer;
	Payee selectedPayee = new Payee();
	String username;
	UserTable user = new UserTable();

	ServiceRequest serviceRequest = new ServiceRequest();
	@Autowired
	IUserService userService;

	@RequestMapping(value = "/userLogin")
	public String getUserLoginPage() {
		return "OBS_User_Login";
	}

	@RequestMapping(value = "/forgot")
	public String getForgotPage(Model m){
			m.addAttribute("temp", "Your temporary password is #sq500");
		return "OBS_User_ForgotPassword";
	}

	@RequestMapping(value = "/userAccount", method = RequestMethod.POST)
	public String getUserAccountPage(@RequestParam("uname") String uname,
			@RequestParam("pwd") String pwd, Model m, HttpSession session)
			throws BankingException {
		String target = "error";
		session.setAttribute("uname", uname);
		username = uname;
		try {
			UserTable user = userService.findUser(username);
			if (pwd.equals(user.getLoginPassword()) || "#sq500".equals(pwd)) {
				target = "OBS_User_AccountLogin";
			} else {

				target = "OBS_User_Error";
			}
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE10);
		}
		return target;
	}

	@RequestMapping("/back")
	public String getHomePage(Model m,HttpSession session) {
		m.addAttribute("user", session.getAttribute("uname"));
		return "OBS_User_Home";
	}

	@RequestMapping(value = "/userHome", method = RequestMethod.POST)
	public String getUserHomePage(@RequestParam("id") Long id, Model m,
			HttpSession session) throws BankingException {
		String target = "error";
		session.setAttribute("accountId", id);
		try {
			UserTable user1 = userService.findUser(username);

			Long userAccId = user1.getAccountId();
			if (userAccId.equals(id)) {
				accountId = id;
				m.addAttribute("user", username);
				target = "OBS_User_Home";
			} else {
				m.addAttribute("valid", "Please Enter a valid Account Number");
				target = "error";
			}
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE9);
		}
		return target;
	}

	@RequestMapping("/view")
	public String viewMiniStatement(Model m) throws BankingException {
		ArrayList<Transactions> list = new ArrayList<Transactions>();
		try {
			list = userService.viewAllTransactions(accountId);
			m.addAttribute("list", list);
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE2);
		}
		return "OBS_User_ViewMiniStatement";
	}

	@RequestMapping("/change")
	public String changeAddress(Model m) throws BankingException {
		try {
			customer = userService.findCustomer(accountId);
			String oldAddress = customer.getAddress();
			m.addAttribute("old", oldAddress);

		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE3);
		}
		return "OBS_User_ChangeAddress";
	}

	@RequestMapping("/updateAddress")
	public String updateAddress(
			@RequestParam("customerAddress") String newAddress, Model m)
			throws BankingException {
		customer.setAddress(newAddress);
		try {
			userService.update(customer);
			m.addAttribute("msg", "updated successfully");
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE3);
		}
		return "success";
	}

	@RequestMapping("/fund")
	public String fundTransfer(@ModelAttribute("payee") Payee payee1, Model m)
			throws BankingException {
		java.sql.Date date = java.sql.Date.valueOf(LocalDate.now());
		m.addAttribute("date", date);

		ArrayList<Payee> list = new ArrayList<Payee>();
		try {
			list = userService.getPayeeList(accountId);
			System.out.println(list);
			ArrayList<Long> pList = new ArrayList<Long>();
			for (Payee payee : list) {

				pList.add(payee.getPayeeId());
			}

			m.addAttribute("myPayee", pList);
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE12);
		}
		return "OBS_User_FundTransfer";
	}

	@RequestMapping("/addPayee")
	public String addPayee(Model m) {
		
		return "OBS_User_AddPayee";
	}

	@RequestMapping("/savePayee")
	public String savePayee(@RequestParam("payeeId") Long id,@RequestParam("nickName") String nickName, Model m) throws BankingException {
		Payee pBean = new Payee();
		String  target="error";
		
		
		try {
			account = userService.findAccount(id);
			ArrayList<Payee> existingPayeeList = new ArrayList<Payee>();
			existingPayeeList = userService.getPayeeList(accountId);
			Account accountHolder = userService.findAccount(accountId);
			if (account == null) {
				m.addAttribute("payeeinvalid",
						"Payee with this Account doesn't exist!!!!!!!");
				target = "error";
			} else if (account != accountHolder) {
				m.addAttribute("sameId", "You Cannot add Yourself as a Payee");
				target = "error";
			}

			else if (existingPayeeList.contains(account)) {

				m.addAttribute("Exist",
						"This Payee is already existed in your PayeeList");
				target = "error";

			} else {
				pBean.setAccountId(accountId);
				pBean.setPayeeId(id);
				pBean.setNickName(nickName);
				userService.saveNewPaye(pBean);
				m.addAttribute("msg1", "payee added successfully");
				target = "success";

			}
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE7);
		}

		
		return target;
	}

	@RequestMapping("/payAmount")
	public String pay(@RequestParam("payeeId") Long pid) {
		selectedPayee.setPayeeId(pid);
		return "OBS_User_PayAmount";
	}

	@RequestMapping("/transfer")
	public String updateBalance(@RequestParam("amount") Long amount,
			@RequestParam("tranpwd") String tranpwd, Model m)
			throws BankingException {
		// Long id=selectedPayee.getPayeeId();
		String target = "error";
		try {
			UserTable uBean = userService.findUser(username);
			if (uBean.getTransactionPassword().equals(tranpwd)) {
				account = userService.findAccount(accountId);
				System.out.println(account.getAccountBalance());
				Long amount1 = account.getAccountBalance();

				if ((amount > amount1)) {
					m.addAttribute("amt", "Insufficient Balance");
					target = "error";
				} else if (amount > 1000000) {
					m.addAttribute("amt",
							"Tranfer Amount should be less than 10Lakhs!!!");
				} else {
					Long amount2 = amount1 - amount;
					account.setAccountBalance(amount2);
					userService.updateAccount(account);
					m.addAttribute("msg2", "Fund Transfered successfully");
					target = "success";
				}
			} else {
				String trn = "Please enter correct transaction password";
				m.addAttribute("trn", trn);
				target = "error";
			}
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE11);
		}
		return target;
	}

	@RequestMapping("/cheque")
	public String requestCheque(Model m) throws BankingException {
		try {
			ServiceRequest sRequest = userService.findService(accountId);
			if (sRequest.getServiceId() == 0) {
				serviceRequest.setServiceDesc("ChequeBook");
				serviceRequest.setServiceStatus("issued");

				serviceRequest.setRaisedDate(java.sql.Date.valueOf(LocalDate
						.now()));
				serviceRequest.setAccountId(accountId);
				int id = userService.getRequestCheque(serviceRequest);
				m.addAttribute("serviceid", id);

			} else {
				String msg = "Your cheque book has already been requested";
				m.addAttribute("requestmsg", msg);
			}
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE5);
		}
		return "OBS_User_RequestChequeBook";
	}

	@RequestMapping("/track")
	public String getServiceStatus(Model m) {
		System.out.println("track");
		ServiceRequest serv = new ServiceRequest();
		m.addAttribute("bean", serv);
		return "OBS_User_TrackService";
	}

	@RequestMapping(value = "/trackservice", method = RequestMethod.POST)
	public String displayServiceStatus(@ModelAttribute("bean") @Valid ServiceRequest bean,BindingResult br,
			Model m) throws BankingException {
		String target = "error";
		if(br.hasErrors())
		{
			target="OBS_User_TrackService";
		}
		else{
		ArrayList<ServiceRequest> servList = new ArrayList<ServiceRequest>();
		try {
			ServiceRequest serviceRequest1;
			serviceRequest1 = userService.checkService(bean.getServiceId());
			if (serviceRequest1 == null) {
				m.addAttribute("invalidservice",
						"such service doesnot exist for your account");
				target = "error";
			} else {
				String serviceStatus = serviceRequest1.getServiceStatus();
				m.addAttribute("serviceStatus", serviceStatus);
				target = "CheckStatus";
			}
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE6);
		}
		}
		return target;
	}

	@RequestMapping("/password")
	public String changePassword() {
		// m.addAttribute("old", oldPassword);
		return "OBS_User_ChangePassword";
	}

	@RequestMapping(value = "/updatePassword", method = RequestMethod.POST)
	public String updatePassword(
			@RequestParam("oldPassword") String oldPassword,
			@RequestParam("newPassword") String newPassword,
			@RequestParam("newPassword1") String newPassword1, Model m) throws BankingException {
		String target = "error";
		try {
			UserTable user = userService.findUser(username);

			if (oldPassword.equals(user.getLoginPassword())) {
				if (newPassword1.equals(newPassword)) {
					user.setLoginPassword(newPassword);
					userService.updatePassword(user);
					m.addAttribute("msgpwd", "updated successfully");
					target = "success";
				}
			} else {
				m.addAttribute("error", "Cant update");
				target = "error";
			}
		} catch (BankingException e) {
			throw new BankingException(IBankingException.USERMESSAGE4);
		}
		return target;
	}
	@RequestMapping(value = "/userlogout")
	public String getUserLogoutPage(Model m,HttpSession session) {
		m.addAttribute("logout", "Successfully Loggedout");
		return "OBS_User_Logout";
	}

}