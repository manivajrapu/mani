package com.cg.obs.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;
import com.cg.obs.exception.BankingException;
import com.cg.obs.exception.IBankingException;
import com.cg.obs.service.IAdminService;


@Controller

public class AdminController {
	@Autowired 
	IAdminService adminService;
	Long id;
	@RequestMapping("/index")
	public  String getIndexPage(){
		return "OBS_All_Index";
	}

	@RequestMapping("/adminLogin")
	public  String getAdminPage(){
		return "OBS_Admin_Login";
	}

	@RequestMapping("/ValidateAdmin")
	public  String getAdminValidationPage(@RequestParam("uname") String admin,@RequestParam("pass") String pass,Model m){
		String target="OBS_Admin_Error";
		if("Admin".equals(admin) && "Admin123".equals(pass)){
			target="OBS_Admin_Home";
		}
		else {
		
			m.addAttribute("adminerror", "Please Enter valid credentials");
		}
		return  target;
	}
	@RequestMapping("/adminHome")
	public  String getAdminHomePage(){
		return "OBS_Admin_Home";
	}
	@RequestMapping("/AddAccountHolder")
	public  String getAddAccountHolderPage(Model m){ 
		m.addAttribute("customer", new Customer());
				return "OBS_Admin_AddAccount";
	}
	@RequestMapping("/ProcessAddAccountHolder")
	public  String process(@ModelAttribute("customer") @Valid Customer customer,BindingResult br,Model m) throws BankingException{
			String target="OBS_Admin_AddAccount";
		try{
			
			if(br.hasErrors()){
				 target="OBS_Admin_AddAccount";
			}
			else{
		id=adminService.saveCustomer(customer);
		
		java.sql.Date date=java.sql.Date.valueOf(LocalDate.now());
		m.addAttribute("date", date);
		System.out.println("1");
		ArrayList<String> list=new ArrayList<>();
		list.add("Current");
		list.add("Savings");
		m.addAttribute("accountList",list);
		System.out.println("2");
		m.addAttribute("accountMaster", new Account());
		 target="OBS_Admin_ProcessAccount";
		}
		}catch(BankingException e){
			throw new BankingException(IBankingException.ADMINMESSAGE2);
		}
		 
		return target;
	} 
	@RequestMapping("/ProcessAccount")
	public  String processAcc(@ModelAttribute("accountMaster") @Valid Account accountMaster,BindingResult br,Model m) throws BankingException{
		String target="OBS_Admin_ProcessAccount";
		try{
			
			if(br.hasErrors()){
				 target="OBS_Admin_ProcessAccount";
			}
			
			else{
		adminService.saveAccount(accountMaster) ;
		String message="Account added successfully";
		m.addAttribute("msg2", message);
		 target="OBS_Admin_Success";
			}
		}catch(BankingException e){
			throw new BankingException(IBankingException.ADMINMESSAGE2);
		}
		 
		return target;
	} 
	
	@RequestMapping("/Transactions")
	public  String getTransactionsPage( Model m){
		
		return "OBS_Admin_ViewTran";
	}
	@RequestMapping("/dailyTransaction") 
	public  String getdailyTransactionPage( Model m) throws BankingException{
		try{
		ArrayList<Transactions> list = new ArrayList<Transactions>();
		java.sql.Date date1=java.sql.Date.valueOf(LocalDate.now());
		list=adminService.getDailyTransactions(date1);
		 m.addAttribute("list", list);
		 
		}
		catch(BankingException e){
			throw new BankingException(IBankingException.ADMINMESSAGE3);
		}
		return "OBS_Admin_DailyTran";
	}
	
	
	@RequestMapping("/allTransaction") 
	public  String getallTransactionPage( Model m) throws BankingException{
		try{
		ArrayList<Transactions> list = new ArrayList<Transactions>();
		
		list=adminService.getallTransactions();
		 m.addAttribute("list", list);
		
		}
		catch(BankingException e){
			throw new BankingException(IBankingException.ADMINMESSAGE3);
		}
		return "OBS_Admin_AllTran";
	}
	@RequestMapping(value = "/adminlogout")
	public String getUserLogoutPage(Model m,HttpSession session) {
		m.addAttribute("logout", "Successfully Loggedout");
		return "OBS_User_Logout";
	}

}
