package com.cg.obs.dao;

import java.sql.Date;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;
import com.cg.obs.exception.BankingException;
import com.cg.obs.exception.IBankingException;

@Repository
public class AdminDaoImpl implements IAdminDao {

	@PersistenceContext
	EntityManager entityManager;
	ArrayList<Transactions> trantList = null;

	@Override
	public ArrayList<Transactions> getDailyTransactions(Date date1)
			throws BankingException {
		// TODO Auto-generated method stub
		String dailyTranQuery = IQueryMapper.FETCH_TRANSACTIONS_CURRENT_DATE;
		try {
			TypedQuery<Transactions> tq = entityManager.createQuery(
					dailyTranQuery, Transactions.class);
			tq.setParameter("date1", date1);
			trantList = (ArrayList<Transactions>) tq.getResultList();
			
		} catch (Exception e) {
			throw new BankingException(
					"Due to some technical problems,transaction cannot be initiated");

		}
		return trantList;
	}

	@Override
	public Long saveCustomer(Customer cBean) throws BankingException {
		// TODO Auto-generated method stub
		Long id;
		System.out.println( "hgdlifk");
		entityManager.persist(cBean);
		entityManager.flush();
		id = cBean.getAccountID();
		return id;
	}

	@Override
	public void saveAccount(Account aBean) throws BankingException {
		// TODO Auto-generated method stub
		entityManager.persist(aBean);
		entityManager.flush();

	}

	@Override
	public ArrayList<Transactions> getallTransactions() throws BankingException {
		// TODO Auto-generated method stub
		String dailyTranQuery = IQueryMapper.FETCH_ADMIN_TRANSACTIONS;
		try {
			TypedQuery<Transactions> tq = entityManager.createQuery(
					dailyTranQuery, Transactions.class);
			
			trantList = (ArrayList<Transactions>) tq.getResultList();
			
		} catch (Exception e) {
			throw new BankingException(
					"Due to some technical problems,transaction cannot be initiated");

		}
		return trantList;
	}

}
