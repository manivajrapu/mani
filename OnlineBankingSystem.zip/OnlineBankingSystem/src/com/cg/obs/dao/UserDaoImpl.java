package com.cg.obs.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.ServiceRequest;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.UserTable;
import com.cg.obs.exception.BankingException;



@Repository
public class UserDaoImpl implements IUserDao{
	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public Customer findCustomer(Long id) {
		// TODO Auto-generated method stub
		Customer c=entityManager.find(Customer.class, id);
		return c;
	}

	@Override
	public void update(Customer customer) {
		// TODO Auto-generated method stub
		entityManager.merge(customer);
		
	}

	@Override
	public ArrayList<Payee> getPayeeList(Long accountId) {
		// TODO Auto-generated method stub
		ArrayList<Payee> payeeList=new ArrayList<Payee>();
		String payeeIdQuery = IQueryMapper.FETCH_PAYEES_GIVEN_ACCOUNT;
		try {
			TypedQuery<Payee> tq = entityManager.createQuery(payeeIdQuery, Payee.class); 
			tq.setParameter("id", accountId); 
			payeeList = (ArrayList<Payee>) tq.getResultList();
	}catch(Exception e){  
		//logger.info(e.getMessage());
		//throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
		e.printStackTrace();
	}
		return payeeList;
	}

	@Override
	public void saveNewPaye(Payee pBean) {
		// TODO Auto-generated method stub
		entityManager.persist(pBean);
		entityManager.flush();
		
	}

	@Override
	public int getRequestCheque(ServiceRequest s) {
		
		entityManager.persist(s);
		entityManager.flush();
		int ser=s.getServiceId();
	
		return ser;
	}

	@Override
	public ServiceRequest checkService(Integer id) {
		ServiceRequest s=entityManager.find(ServiceRequest.class, id);
		return s;
	}

	@Override
	public ServiceRequest checkService(Long accountId) {
		// TODO Auto-generated method stub
		ServiceRequest s=new ServiceRequest();
		String serviceQuery = IQueryMapper.FETCH_SERVICE_GIVEN_ACCOUNT;
		try {
			TypedQuery<ServiceRequest> tq = entityManager.createQuery(serviceQuery, ServiceRequest.class); 
			tq.setParameter("id", accountId); 
			s = tq.getSingleResult();
	}catch(Exception e){  
		//logger.info(e.getMessage());
		//throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
		e.printStackTrace();
	}
		return s;
	}

	@Override
	public UserTable findUser(String username) {
		// TODO Auto-generated method stub
		UserTable u=entityManager.find(UserTable.class, username);
		System.out.println(u);
		return u;
	} 

	/*@Override
	public UserBean findUserBean(Long accountId) {
		// TODO Auto-generated method stub 
		UserBean u=entityManager.find(UserBean.class, accountId);
		return u;
	}

	@Override
	public void updateAccount(Account account) {
		// TODO Auto-generated method stub
		entityManager.merge(account);
	}*/
	@Override 
    public ArrayList<Transactions> viewAllTransactions(Long id) throws BankingException{
           // TODO Auto-generated method stub
		ArrayList<Transactions> tranList = new ArrayList<Transactions>();
           String TranQuery = IQueryMapper.FETCH_ALL_TRANSACTIONS;
           TypedQuery<Transactions> tq = entityManager.createQuery(TranQuery, Transactions.class);
           tq.setParameter("id", id);
           
           tranList =  (ArrayList<Transactions>) tq.getResultList();
           
           return tranList;
    }
	@Override
    public UserTable findCustomerForPassword(Long accountId) throws BankingException{
		UserTable user=new UserTable();
		String userQuery = IQueryMapper.FETCH_USER_GIVEN_ACCOUNT;
		try {
			TypedQuery<UserTable> tq = entityManager.createQuery(userQuery, UserTable.class); 
			tq.setParameter("id", accountId); 
			user = tq.getSingleResult();
	}catch(Exception e){  
		//logger.info(e.getMessage());
		//throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
		e.printStackTrace();
	}
		return user;
    }

    @Override
    public void updatePassword(UserTable user) throws BankingException{
           // TODO Auto-generated method stub
           entityManager.merge(user);

    }

	@Override
	public void updateAccount(Account account) throws BankingException{
		// TODO Auto-generated method stub
		 entityManager.merge(account);
	}

	@Override
	public Account findAccount(Long accountId) throws BankingException{
		// TODO Auto-generated method stub 
		Account a=entityManager.find(Account.class, accountId);
		return  a;
	}

	

}
