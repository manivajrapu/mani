package com.cg.obs.dao;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;
import com.cg.obs.exception.BankingException;



public interface IAdminDao {

	ArrayList<Transactions> getDailyTransactions(Date date1) throws BankingException;

	

	Long saveCustomer(Customer cBean) throws BankingException;



	void saveAccount(Account aBean)throws BankingException;



	ArrayList<Transactions> getallTransactions() throws BankingException;



	



	

}
