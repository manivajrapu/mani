package com.cg.obs.dao;

public interface IQueryMapper {
	public static final String FETCH_TRANSACTIONS_CURRENT_DATE="SELECT t FROM Transactions t WHERE t.date=:date1 " ;
	public static final String FETCH_TRANSACTIONS_GIVEN_MONTH = "SELECT t FROM Transactions t WHERE to_char(t.date,'fmMonth')=:month" ;
	public static final String FETCH_PAYEES_GIVEN_ACCOUNT = "SELECT p FROM Payee p WHERE p.accountId=:id";
	public static final String FETCH_SERVICE_GIVEN_ACCOUNT = "SELECT s FROM  ServiceRequest WHERE s.accountId=:id ";
	public static final String FETCH_ALL_TRANSACTIONS = "SELECT t FROM Transactions t WHERE t.accountId=:id ";
	public static final String FETCH_USER_GIVEN_ACCOUNT = "SELECT u FROM  UserTable WHERE u.accountId=:id ";
	public static final String FETCH_ADMIN_TRANSACTIONS = "SELECT t FROM Transactions t  ";
}
  