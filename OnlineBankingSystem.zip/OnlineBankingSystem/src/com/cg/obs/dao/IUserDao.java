package com.cg.obs.dao;

import java.util.ArrayList;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Payee;
//import com.cg.obs.bean.UserBean;
import com.cg.obs.bean.ServiceRequest;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.UserTable;
import com.cg.obs.exception.BankingException;

public interface IUserDao {

	

	Customer findCustomer(Long id)throws BankingException;

	void update(Customer customer)throws BankingException;

	ArrayList<Payee> getPayeeList(Long accountId)throws BankingException;



	void saveNewPaye(Payee pBean)throws BankingException;

	/*UserBean findUserBean(Long accountId);*/

/*	void updateAccount(Account account);*/

	int getRequestCheque(ServiceRequest s)throws BankingException;

	ServiceRequest checkService(Integer id)throws BankingException;

	ServiceRequest checkService(Long accountId)throws BankingException;


	ArrayList<Transactions> viewAllTransactions(Long id)throws BankingException;

	UserTable findUser(String username)throws BankingException;

	UserTable findCustomerForPassword(Long accountId)throws BankingException;

	void updatePassword(UserTable user)throws BankingException;

	void updateAccount(Account account)throws BankingException;

	Account findAccount(Long accountId)throws BankingException;
}
