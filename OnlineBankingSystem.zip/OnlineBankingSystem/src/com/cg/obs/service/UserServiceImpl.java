package com.cg.obs.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Payee;
import com.cg.obs.bean.ServiceRequest;
import com.cg.obs.bean.Transactions;
import com.cg.obs.bean.UserTable;
//import com.cg.obs.bean.UserBean;
import com.cg.obs.dao.IUserDao;
import com.cg.obs.exception.BankingException;


@Service
@Transactional
public class UserServiceImpl implements IUserService{

	
	@Autowired
	IUserDao userDao;
	
	@Override
	public Customer findCustomer(Long id) throws BankingException {
		// TODO Auto-generated method stub
		return userDao.findCustomer(id);
	}
	@Override
	public void update(Customer customer) throws BankingException {
		// TODO Auto-generated method stub
		userDao.update(customer);
	}
	@Override
	public ArrayList<Payee> getPayeeList(Long accountId) throws BankingException {
		// TODO Auto-generated method stub
		return userDao.getPayeeList(accountId);
	}
	@Override
	public void saveNewPaye(Payee pBean) throws BankingException{
		// TODO Auto-generated method stub
		userDao.saveNewPaye(pBean);
	}
	
	@Override
	public int getRequestCheque(ServiceRequest s) throws BankingException{
		// TODO Auto-generated method stub
		return userDao.getRequestCheque(s);
	}
	@Override
	public ServiceRequest checkService(Integer id) throws BankingException{
		// TODO Auto-generated method stub
		return userDao.checkService(id);
	}
	@Override
	public ServiceRequest findService(Long accountId) throws BankingException{
		// TODO Auto-generated method stub
		return userDao.checkService(accountId);
	}
	@Override
	public UserTable findUser(String username) throws BankingException{
		// TODO Auto-generated method stub
		return userDao.findUser(username);
	}
	@Override 
    public ArrayList<Transactions> viewAllTransactions(Long id) throws BankingException{
           // TODO Auto-generated method stub
           return userDao.viewAllTransactions(id);
    }

	@Override
    public UserTable findCustomerForPassword(Long accountId) throws BankingException{
           // TODO Auto-generated method stub
           return userDao.findCustomerForPassword(accountId);
    }
    @Override
    public void updatePassword(UserTable user) throws BankingException{
           // TODO Auto-generated method stub
           userDao.updatePassword(user);
    }
	@Override
	public void updateAccount(Account account) throws BankingException{
		// TODO Auto-generated method stub
		 userDao.updateAccount(account);
	}
	@Override
	public Account findAccount(Long accountId) throws BankingException{
		// TODO Auto-generated method stub
		   return userDao.findAccount(accountId);
	}


}
