package com.cg.obs.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

//import org.hibernate.validator.constraints.NotBlank;
@Entity
@Table(name="Payee_Table")
public class Payee {
	
	@Id
	@Column(name="Payee_Account_ID")
	private Long payeeId;
	@Column(name="Account_ID")
	private Long accountId;
	@NotBlank
	@Pattern(regexp="[A-Za-z]{4,6}",message="Please enter valid name")
	@Column(name="Nick_Name")
	private String nickName;
	public Long getPayeeId() {
		return payeeId;
	} 
	public void setPayeeId(Long payeeId) {
		this.payeeId = payeeId;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	
}
