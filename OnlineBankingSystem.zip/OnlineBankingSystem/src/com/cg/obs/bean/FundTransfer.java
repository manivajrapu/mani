package com.cg.obs.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="Fund_Transfer")
public class FundTransfer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="fid_seq")
	@SequenceGenerator(name="fid_seq")
	@Column(name="FundTransfer_ID")
	private Long fundTransferId;
	@Column(name="Account_ID")
	private Long accountId;
	@Column(name="Payee_Account_ID")
	private Long payeeId;
	@Column(name="Date_Of_Transfer")
	private Date date;
	@Column(name="Transfer_Amount")
	private Long amount;
	public Long getFundTransferId() {
		return fundTransferId;
	}
	public void setFundTransferId(Long fundTransferId) {
		this.fundTransferId = fundTransferId;
	}
	public Long getAccountId() {
		return accountId;
	}
	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}
	public Long getPayeeId() {
		return payeeId;
	}
	public void setPayeeId(Long payeeId) {
		this.payeeId = payeeId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	
	

}
