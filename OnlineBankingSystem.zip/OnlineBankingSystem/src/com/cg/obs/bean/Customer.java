package com.cg.obs.bean;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="Customer")
public class Customer implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="accid_seq")
	@SequenceGenerator(name="accid_seq",allocationSize=1,initialValue=300001)
	@Column(name="Account_ID ")
	private Long accountID;
	
	@Pattern(regexp="[A-Z]{1}[a-z]{4,20}",message="Please enter valid customer")
	@Column(name="customer_name  ")
	private String customerName;
	
	@Pattern(regexp="[A-Za-z0-9]+@[A-Za-z0-9]+[.][A-Za-z]{2,4}",message="Please enter valid Email ID")
	@Column(name="email ")
	private String email;
	@Column(name="address")
	private String address ;
	
	@Pattern(regexp="[A-Z]{5}+[0-9]{4}+[A-Z]",message="Please enter valid pancard number")
	@Column(name="pancard")
	private String panCard  ;
	public Long getAccountID() {
		return accountID;
	}
	public void setAccountID(Long accountID) {
		this.accountID = accountID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) { 
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPanCard() {
		return panCard;
	}
	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}
	
}
