package com.cg.obs.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="Service_Tracker")
public class ServiceRequest {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sid_seq")
@SequenceGenerator(name="sid_seq",allocationSize=1)
@Column(name="Service_ID")
private int serviceId;
@Column(name="Service_Description")
private String serviceDesc;
@Column(name="Account_ID")
private Long accountId; 
@Column(name="Service_Raised_Date")
private Date raisedDate;
@Column(name="Service_status")
private String serviceStatus;
public int getServiceId() {
	return serviceId;
}
public void setServiceId(int serviceId) {
	this.serviceId = serviceId;
}
public String getServiceDesc() {
	return serviceDesc;
}
public void setServiceDesc(String serviceDesc) {
	this.serviceDesc = serviceDesc;
}

public Long getAccountId() {
	return accountId;
}
public void setAccountId(Long accountId) {
	this.accountId = accountId;
}
public Date getRaisedDate() {
	return raisedDate;
}
public void setRaisedDate(Date raisedDate) {
	this.raisedDate = raisedDate;
}
public String getServiceStatus() {
	return serviceStatus;
}
public void setServiceStatus(String serviceStatus) {
	this.serviceStatus = serviceStatus;
}
@Override
public String toString() {
	return "ServiceRequest [serviceId=" + serviceId + ", serviceDesc="
			+ serviceDesc + ", accountId=" + accountId + ", raisedDate="
			+ raisedDate + ", serviceStatus=" + serviceStatus + "]";
}

}
