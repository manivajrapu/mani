package com.cg.obs.exception;

public interface IBankingException {

String ADMINMESSAGE1 = "Cannot create new account";
String ADMINMESSAGE2 = "Problem while connectig to database.";
String ADMINMESSAGE3 = "Cannot view the transactions, internal database problem";
String MESSAGE4 = "Unable to retrieve the details, please enter the dates correctly";

String USERMESSAGE1= "Please enter a valid password";
String USERMESSAGE2 = "Unable to display your transactions";
String USERMESSAGE3 = "Unable to change the communication address";
String USERMESSAGE4 = "Unable to change the password, please re-enter the password correctly";
String USERMESSAGE5 = "Cannot process your request";
String USERMESSAGE6="Not a valid Service ID";
String USERMESSAGE7 = "Cannot register a new payee!!! Try again";
String USERMESSAGE8 = "Unable to send OTP at the moment";
String USERMESSAGE9 = "Invalid Account ID";
String USERMESSAGE10 = "Unable to login into your account!!!";
String USERMESSAGE11 = "Unable to transfer the amount...Try after some time";
String USERMESSAGE12 = "Cannot display your payee list due to some error";
}