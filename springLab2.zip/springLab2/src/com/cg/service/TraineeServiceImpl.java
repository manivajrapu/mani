package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.TraineeDao;
import com.cg.entity.Trainee;
@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {

	
	@Autowired
	private TraineeDao traineeDao;
	@Override
	public void save(Trainee trainee) {
		// TODO Auto-generated method stub
		traineeDao.save(trainee);
	}
	@Override
	public Trainee find(Integer id) {
		// TODO Auto-generated method stub
		return traineeDao.find(id);
	}
	@Override
	public void removeTrainee(Trainee trainee1) {
		// TODO Auto-generated method stub
		traineeDao.removeTrainee(trainee1);
	}
	@Override
	public List<Trainee> retrieveall() {
		// TODO Auto-generated method stub
		return traineeDao.retrieveall();
	}

}
