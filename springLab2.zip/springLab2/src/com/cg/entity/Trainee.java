package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="trainee_details")
public class Trainee implements Serializable{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@Id
@Column(name="trainee_id")
public Integer traineeId;
@Column(name="trainee_name")
public String  traineeName;
@Column(name="trainee_domain")
public String traineeDomain;
@Column(name="trainee_location")
public String traineeLocation;
public Integer getTraineeId() {
	return traineeId;
}
public void setTraineeId(Integer traineeId) {
	this.traineeId = traineeId;
}
public String getTraineeName() {
	return traineeName;
}
public void setTraineeName(String traineeName) {
	this.traineeName = traineeName;
}
public String getTraineeDomain() {
	return traineeDomain;
}
public void setTraineeDomain(String traineeDomain) {
	this.traineeDomain = traineeDomain;
}
public String getTraineeLocation() {
	return traineeLocation;
}
public void setTraineeLocation(String traineeLocation) {
	this.traineeLocation = traineeLocation;
}

}
